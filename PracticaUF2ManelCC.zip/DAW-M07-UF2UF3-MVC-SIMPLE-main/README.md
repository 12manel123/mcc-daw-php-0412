
Una aplicació d'esquelet MVC extremadament senzilla i fàcil d'entendre, reduïda al màxim.

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="POST" action="{{url('api/products')}}">
	Nom<input type="text" name="nom"><br>
	Desc.<input type="text" name="descripcio"><br>
	Preu<input type="number" name="preu"><br>
	<input type="submit" name="">
</form>
</body>
</html>
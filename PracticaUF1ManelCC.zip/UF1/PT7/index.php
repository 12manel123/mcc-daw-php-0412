<!DOCTYPE html>
  <h3>Tabla mutiplicar</h3>
<?php
//variables
$num=1;
$cont=10;
$num2=5;

//aplicar varaibles
while($num<=$cont){
	echo $num.' x '.$num2.' = '.($num*$num2).'<br/>';
	$num++;
}
?>



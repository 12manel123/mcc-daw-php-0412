<?php
	echo "Hola lhe creat<br>";
	setcookie("nom","Anna");
	echo $_COOKIE['nom'];
?>
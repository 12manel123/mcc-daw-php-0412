<?php
$cont=1;
$numero=7;

while ($cont<$numero){
	$cont2=1;

	while ($cont2<$numero){
		echo ($cont*$cont2)." ";
		$cont2++;
	
	}
	echo "<br/>";
$cont++;
}

?>
<?php	include 'seguretat.php';?><!--Sinonimos: include_once-->
<?php	include 'menu.php';?>
<?php	include 'cap.php';?>

<div class="container">

<h2>
<?php
echo "Hola ".$_SESSION['username'];
?></h2>
<p>Petita operacio per fer mutiplicacions y demés</p>
</div>

<?php	include 'peu.php';?>


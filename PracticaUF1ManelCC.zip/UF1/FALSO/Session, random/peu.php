<hr>
 <?php	include 'navbar.php';?>
</body>
</html>
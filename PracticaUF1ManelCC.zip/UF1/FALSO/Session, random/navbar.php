<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <form class="d-flex">
      <input class="form-control me-2" type="search" placeholder="Cerca" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Cerca</button>
    </form>
  </div>
</nav>
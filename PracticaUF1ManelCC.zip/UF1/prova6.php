<?php
	if(isset($_COOKIE['comptador']))
	{
		setcookie('comtador')
	}



?>
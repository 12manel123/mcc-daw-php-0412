<ul class="nav justify-content-end">
 
    <li class="nav-item">
        <a class="nav-link" href="index.php">Home
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="opcio1.php">Opció 1
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="opcio2.php">Opció 2
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="opcio3.php">Opció 3
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="desconnectar.php">Logout
        </a>
    </li>

    
    
</ul>
<hr>
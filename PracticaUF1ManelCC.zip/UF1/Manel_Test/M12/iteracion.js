for (x of obj) {
  console.log(x.name + ' ' + x.email);
}
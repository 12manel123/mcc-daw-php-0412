var data = {

 "name": "edinson",
 "surname": "carranza saldaña",
 "age": 24
}


console.log(obj.name) //edinson
console.log(obj.surname) //carranza saldaña
console.log(obj.age) //24

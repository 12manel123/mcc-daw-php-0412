<?php
	session_start();
	$_SESSION['nom'] = 'Ana';

?>
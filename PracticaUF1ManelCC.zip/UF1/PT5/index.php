<?php
$numsLinks= 4;
$cont=1;
$link1='desti.html';
while ($cont<=4){
echo '<a href="'.$link1.'">LINK'.$cont.' </a>';
$cont++;
}

?>
